# myhttps
#### alpha version
pip install myhttps